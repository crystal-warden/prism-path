package comparison.sensor_interlock

import data.comparison.sensor_interlock.decision

cond_r2 if {
	input.temp_c >= 150
}

cond_r2 if {
	input.pressure_kpa >= 900
}

cond_r3 if {
	input.temp_c >= 120
}

cond_r3 if {
	input.pressure_kpa >= 750
}
